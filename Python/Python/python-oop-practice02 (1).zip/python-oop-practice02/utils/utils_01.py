books = [
    ("Atomic Habits", "James Clear", 2018, 10.99, "Available"),
    ("Deep Work", "Cal Newport", 2016, 12.99, "Unavailable"),
    ("The Alchemist", "Paulo Coelho", 1988, 15.99, "Available"),
    ("To Kill a Mockingbird", "Harper Lee", 1960, 11.99, "Unavailable"),
    ("1984", "George Orwell", 1949, 12.99, "Available")
]
