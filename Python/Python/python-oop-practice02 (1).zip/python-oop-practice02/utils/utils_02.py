bankAccounts = [
    ("1234567890","John Doe",1000),
    ("1234567891","Jane Smith",2000),
    ("1234567892","Jim Beam",3000),
    ("1234567893","Jill Johnson",4000),
    ("1234567894","Jack Johnson",5000)
]