movies = [
    {"title": "The Dark Knight", "genre": "Action", "year": 2008},
    {"title": "The Godfather", "genre": "Drama", "year": 1972},
    {"title": "The Lord of the Rings: The Return of the King", "genre": "Adventure", "year": 2003},
    {"title": "The Matrix", "genre": "Action", "year": 1999},
    {"title": "The Silence of the Lambs", "genre": "Drama", "year": 1991}
]