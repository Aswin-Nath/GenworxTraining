
users = [
    {"name": "John Doe", "email": "john@example.com", "password": "password123"},
    {"name": "Jane Smith", "email": "jane@example.com", "password": "password456"},
    {"name": "Jim Beam", "email": "jim@example.com", "password": "password789"},
    {"name": "Jill Johnson", "email": "jill@example.com", "password": "password101"},
    {"name": "Jack Johnson", "email": "jack@example.com", "password": "password111"}
]

addresses = [
    {"street": "100 MG Road", "city": "Bangalore", "pincode": "560001"},
    {"street": "200 Park Street", "city": "Chennai", "pincode": "600001"},
    {"street": "300 Anna Salai", "city": "Hyderabad", "pincode": "500001"},
    {"street": "400 Brigade Rd", "city": "Mumbai", "pincode": "400001"},
    {"street": "500 Residency Rd", "city": "Delhi", "pincode": "110001"}
]
